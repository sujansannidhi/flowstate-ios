# FlowState iPhone Simulator

An interactive iPhone simulator for FlowState, the highway speed-advisory app. Open FlowState, start a ride, pick a destination in the map app, and follow the speed advice in the Dynamic Island.

The whole simulator is one static file, `index.html`. There is no build step. Every push to `main` deploys to Vercel.
